package com.petcare.delete.AddPuppiesCart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.petcare.delete.AddPuppiesCart.model.CartPojo;
import com.petcare.delete.AddPuppiesCart.repo.AddCartRepository;


//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AddCartController {
	
	@Autowired
	AddCartRepository cartrepo;
	
	 @PostMapping("/cart/add")
		public CartPojo addCart(@RequestBody CartPojo customer) {

		 CartPojo _customer = cartrepo.save(new CartPojo(customer.getUname(),customer.getCustomer()));
			return _customer;
		}
}
