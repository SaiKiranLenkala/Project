package com.petcare.delete.AddPuppiesCart.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.petcare.delete.AddPuppiesCart.model.CartPojo;

public interface AddCartRepository extends MongoRepository<CartPojo, String>{

}
